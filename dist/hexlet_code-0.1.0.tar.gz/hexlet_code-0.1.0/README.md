### Hexlet tests and linter status:
[![Actions Status](https://github.com/zhukata/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/zhukata/python-project-50/actions)
<!-- [![Maintainability](https://api.codeclimate.com/v1/badges/df66c0cbbeca7d822f23/maintainability)](https://codeclimate.com/github/hexlet-boilerplates/python-package/maintainability)
[![Test Coverage](https://api.codeclimate.com/v1/badges/df66c0cbbeca7d822f23/test_coverage)](https://codeclimate.com/github/hexlet-boilerplates/python-package/test_coverage) -->

Gendiff Step 3:
[![asciicast](https://asciinema.org/a/646480.svg)](https://asciinema.org/a/646480)