def plain(value):
    pass
